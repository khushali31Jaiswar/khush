-- VANTAGE360 Week 7: Customer Intelligence / Retention QA queries
-- Adapt table and column names to the approved source schema before execution.
-- Never treat the rule-based proxy as a validated ML prediction.

-- 1) Customer population and unique key validation
SELECT COUNT(*) AS rows, COUNT(DISTINCT customer_id) AS unique_customers
FROM customer_intelligence;

-- 2) Duplicate customer IDs
SELECT customer_id, COUNT(*) AS row_count
FROM customer_intelligence
GROUP BY customer_id HAVING COUNT(*) > 1;

-- 3) Lifecycle segment reconciliation
SELECT lifecycle_segment, COUNT(DISTINCT customer_id) AS customers,
       AVG(lifetime_value) AS avg_lifetime_value,
       AVG(attrition_risk_proxy_score) AS avg_proxy_score,
       AVG(recency_days) AS avg_recency_days
FROM customer_intelligence
GROUP BY lifecycle_segment ORDER BY customers DESC;

-- 4) Value-risk matrix: distinguish elevated risk from High risk band
SELECT high_value_flag, risk_band, COUNT(DISTINCT customer_id) AS customers,
       AVG(lifetime_value) AS avg_lifetime_value,
       AVG(recency_days) AS avg_recency_days
FROM customer_intelligence
GROUP BY high_value_flag, risk_band
ORDER BY high_value_flag DESC, risk_band;

-- 5) Priority intervention queue (proxy-based; review before outreach)
SELECT customer_id, lifecycle_segment, risk_band, lifetime_value,
       attrition_risk_proxy_score, recency_days, return_rate,
       open_escalated_tickets, avg_csat
FROM customer_intelligence
WHERE high_value_elevated_risk = 'Yes'
ORDER BY attrition_risk_proxy_score DESC, lifetime_value DESC, recency_days DESC;

-- 6) At-risk / win-back profile
SELECT COUNT(DISTINCT customer_id) AS customers,
       AVG(lifetime_value) AS avg_lifetime_value,
       AVG(attrition_risk_proxy_score) AS avg_proxy_score,
       AVG(recency_days) AS avg_recency_days,
       AVG(return_rate) AS avg_return_rate
FROM customer_intelligence
WHERE lifecycle_segment = 'At-risk / win-back';

-- 7) ML score join coverage - run after receiving the finalized model output
-- SELECT COUNT(*) AS joined_rows, COUNT(DISTINCT c.customer_id) AS customers,
--        COUNT(m.customer_id) AS matched_model_rows
-- FROM customer_intelligence c
-- LEFT JOIN customer_risk_scoring_v2 m USING (customer_id);
