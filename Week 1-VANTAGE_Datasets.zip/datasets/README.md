# InsightPulse Datasets — RetailNova Pvt. Ltd.
## Technocolabs Internship 2025

---

## Files Included

| File | Rows | Size | Description |
|------|------|------|-------------|
| customers.csv | 5,000 | ~485 KB | Customer demographics, segments, lifetime value |
| products.csv | 40 | ~3 KB | Product catalogue with pricing & cost |
| transactions.csv | 50,000 | ~4.6 MB | Purchase records (Jan 2023 — Dec 2024) |
| customer_support.csv | 8,000 | ~1.1 MB | Support tickets with CSAT scores |
| marketing_campaigns.csv | 500 | ~56 KB | Campaign performance metrics |

**Total: ~63,540 records across 5 related tables**

---

## Data Period
January 2023 — December 2024 (2 years)

## Relationships
- transactions.customer_id → customers.customer_id
- transactions.product_id → products.product_id
- customer_support.customer_id → customers.customer_id
- customer_support.transaction_id → transactions.transaction_id

## Known Data Quality Issues (intentional for learning)
1. `customer_support.csat_score` — NULL for unresolved tickets
2. `customer_support.close_date` — empty string for open tickets
3. `transactions.delivery_days` — NULL for Returned/Cancelled/Pending orders
4. Some Dormant customers have 0 orders but non-null lifetime_value
5. Campaign `conversions` may be 0 for awareness campaigns

## Loading Instructions (Python)
```python
import pandas as pd

customers   = pd.read_csv('customers.csv')
products    = pd.read_csv('products.csv')
transactions= pd.read_csv('transactions.csv', parse_dates=['order_date'])
support     = pd.read_csv('customer_support.csv', parse_dates=['open_date'])
campaigns   = pd.read_csv('marketing_campaigns.csv', parse_dates=['start_date','end_date'])
```

## Disclaimer
All data is **synthetically generated** for educational purposes.
No real customer data is used. Company "RetailNova Pvt. Ltd." is fictional.
Generated for the Technocolabs Summer 2025 Internship Program.
